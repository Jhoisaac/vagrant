if [ ! -f "/home/vagrant/.ssh/id_rsa" ]; then
  ssh-keygen -t rsa -N "" -b 4096 -f /home/vagrant/.ssh/id_rsa
fi

cp /home/vagrant/.ssh/id_rsa.pub /vagrant/control.pub

cat << 'SSHEOF' > /home/vagrant/.ssh/config
Host *
  StrictHostKeyChecking no
  UserKnownHostsFile=/dev/null
SSHEOF

chown -R vagrant:vagrant /home/vagrant/.ssh/

sudo apt-get update
sudo apt-get install -y python3 python3-pip
sudo apt install ansible

cd /vagrant
ansible-galaxy install -r requirements.yml
cp -R /root/.ansible /home/vagrant/.
chown -R vagrant:vagrant /home/vagrant/.ansible
